<?php

//Config functions for Repair Status Main Script
//Copyright (c) 2014, Chris Formeister. All Rights Reserved.

//MySQL Variables

$servername = "localhost";		//Name of Server, ex. localhost
$username = "";			//Username ex. root
$password = "";		//Password ex. root
$dbname = "repairstatus";	//Database Name, ex. repairstatus

?>